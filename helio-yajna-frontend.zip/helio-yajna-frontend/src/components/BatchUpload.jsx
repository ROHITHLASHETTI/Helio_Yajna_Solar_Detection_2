import { useState, useRef } from 'react'
import { detectBatch } from '../api.js'
import ResultCard from './ResultCard.jsx'
import StatusBadge from './StatusBadge.jsx'

export default function BatchUpload() {
  const [files, setFiles] = useState([])
  const [results, setResults] = useState([])
  const [selected, setSelected] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [drag, setDrag] = useState(false)
  const inputRef = useRef(null)

  function handleFiles(list) {
    const arr = Array.from(list || [])
    if (arr.length === 0) return
    setFiles(arr)
    setResults([])
    setSelected(null)
    setError(null)
  }

  async function runBatch() {
    if (files.length === 0) return
    setLoading(true)
    setError(null)
    try {
      const data = await detectBatch(files)
      const list = Array.isArray(data) ? data : data.results || []
      setResults(list)
      setSelected(list[0] || null)
    } catch (err) {
      setError(err.message || 'Batch detection failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="two-col">
      <div className="panel">
        <div className="panel-header">
          <h2>Batch upload</h2>
          <span className="helper-text">{files.length} file(s)</span>
        </div>
        <div className="panel-body">
          <div
            className={`dropzone ${drag ? 'drag' : ''}`}
            onClick={() => inputRef.current?.click()}
            onDragOver={(e) => {
              e.preventDefault()
              setDrag(true)
            }}
            onDragLeave={() => setDrag(false)}
            onDrop={(e) => {
              e.preventDefault()
              setDrag(false)
              handleFiles(e.dataTransfer.files)
            }}
          >
            <div className="icon">▤</div>
            <p>{files.length > 0 ? `${files.length} images selected` : 'Drop multiple images, or click to browse'}</p>
            <div className="hint">rooftop set · verification batch</div>
          </div>
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            multiple
            hidden
            onChange={(e) => handleFiles(e.target.files)}
          />

          {error && (
            <div className="error-banner" style={{ marginTop: 14 }}>
              {error}
            </div>
          )}

          <button
            className="btn btn-primary"
            style={{ marginTop: 16 }}
            onClick={runBatch}
            disabled={files.length === 0 || loading}
          >
            {loading && <span className="spinner" />}
            {loading ? 'Processing batch…' : `Run batch (${files.length})`}
          </button>

          {results.length > 0 && (
            <div style={{ marginTop: 20, maxHeight: 360, overflow: 'auto', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)' }}>
              <table className="batch-table">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Solar</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  {results.map((r, i) => (
                    <tr
                      key={r.sample_id ?? i}
                      className={selected === r ? 'selected' : ''}
                      onClick={() => setSelected(r)}
                    >
                      <td>{r.sample_id ?? i}</td>
                      <td>{r.has_solar ? 'Yes' : 'No'}</td>
                      <td>
                        <StatusBadge status={r.qc_status} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <div className="panel">
        <div className="panel-header">
          <h2>Sample detail</h2>
        </div>
        <div className="panel-body">
          <ResultCard result={selected} />
        </div>
      </div>
    </div>
  )
}
