const LABELS = {
  VERIFIABLE: 'Verifiable',
  FLAGGED: 'Flagged',
  PENDING: 'Pending review',
  NOT_FOUND: 'No panel found',
}

export default function StatusBadge({ status }) {
  const key = (status || 'PENDING').toLowerCase()
  const label = LABELS[status] || status || 'Unknown'
  return <span className={`badge ${key}`}>{label}</span>
}
