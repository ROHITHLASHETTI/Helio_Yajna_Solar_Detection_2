import StatusBadge from './StatusBadge.jsx'

function fmt(n, digits = 2) {
  if (n === null || n === undefined || Number.isNaN(n)) return '—'
  return Number(n).toFixed(digits)
}

export default function ResultCard({ result, previewUrl }) {
  if (!result) {
    return (
      <div className="result-empty">
        <div>No result yet</div>
        <div className="mono">run a detection to see output here</div>
      </div>
    )
  }

  const {
    sample_id,
    lat,
    lon,
    has_solar,
    confidence,
    pv_area_sqm_est,
    euclidean_distance_m_est,
    buffer_radius_sqft,
    qc_status,
    bbox_or_mask,
    image_metadata,
  } = result

  const hasMask = Array.isArray(bbox_or_mask) && bbox_or_mask.length > 0

  return (
    <div>
      <div className="result-head">
        <div>
          <div className="id">SAMPLE {sample_id ?? '—'}</div>
          <div className="coords">
            {fmt(lat, 4)}, {fmt(lon, 4)}
          </div>
        </div>
        <StatusBadge status={qc_status} />
      </div>

      <div className="mask-frame">
        {previewUrl && <img src={previewUrl} alt={`Sample ${sample_id}`} />}
        {hasMask ? (
          <svg viewBox="0 0 1280 1280" preserveAspectRatio="none">
            <polygon
              points={bbox_or_mask.map((p) => p.join(',')).join(' ')}
              fill="rgba(242,165,60,0.22)"
              stroke="var(--solar)"
              strokeWidth="4"
            />
          </svg>
        ) : (
          !previewUrl && <span className="placeholder">no mask data returned</span>
        )}
      </div>

      <div className="metric-grid">
        <div className="metric-tile">
          <div className="label">Solar present</div>
          <div className={`value ${has_solar ? 'accent' : ''}`}>{has_solar ? 'Yes' : 'No'}</div>
        </div>
        <div className="metric-tile">
          <div className="label">Confidence</div>
          <div className="value">{confidence !== undefined ? `${fmt(confidence * 100, 1)}%` : '—'}</div>
        </div>
        <div className="metric-tile">
          <div className="label">PV area est.</div>
          <div className="value">{fmt(pv_area_sqm_est)} m²</div>
        </div>
        <div className="metric-tile">
          <div className="label">Distance est.</div>
          <div className="value">{fmt(euclidean_distance_m_est)} m</div>
        </div>
        <div className="metric-tile">
          <div className="label">Buffer radius</div>
          <div className="value">{buffer_radius_sqft ?? '—'} sqft</div>
        </div>
        <div className="metric-tile">
          <div className="label">Inference mode</div>
          <div className="value" style={{ fontSize: 13 }}>
            {image_metadata?.inference_mode ?? '—'}
          </div>
        </div>
      </div>

      <table className="meta-table">
        <tbody>
          <tr>
            <td>Image source</td>
            <td>{image_metadata?.source ?? '—'}</td>
          </tr>
          <tr>
            <td>Capture date</td>
            <td>{image_metadata?.capture_date ?? '—'}</td>
          </tr>
          <tr>
            <td>Zoom level</td>
            <td>{image_metadata?.zoom ?? '—'}</td>
          </tr>
        </tbody>
      </table>
    </div>
  )
}
