import { useEffect, useState } from 'react'
import { fetchHistory } from '../api.js'
import StatusBadge from './StatusBadge.jsx'

export default function Dashboard() {
  const [history, setHistory] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    let cancelled = false
    fetchHistory()
      .then((data) => {
        if (!cancelled) setHistory(Array.isArray(data) ? data : data.results || [])
      })
      .catch((err) => {
        if (!cancelled) setError(err.message || 'Could not load history')
      })
      .finally(() => {
        if (!cancelled) setLoading(false)
      })
    return () => {
      cancelled = true
    }
  }, [])

  const total = history.length
  const verified = history.filter((r) => r.has_solar).length
  const flagged = history.filter((r) => r.qc_status === 'FLAGGED').length
  const totalArea = history.reduce((sum, r) => sum + (r.pv_area_sqm_est || 0), 0)

  return (
    <div>
      <div className="stat-row">
        <div className="stat-card">
          <div className="label">Sites verified</div>
          <div className="value">{total}</div>
        </div>
        <div className="stat-card">
          <div className="label">Solar detected</div>
          <div className="value accent">{verified}</div>
        </div>
        <div className="stat-card">
          <div className="label">Flagged for review</div>
          <div className="value">{flagged}</div>
        </div>
        <div className="stat-card">
          <div className="label">Cumulative PV area</div>
          <div className="value">{totalArea.toFixed(0)} m²</div>
        </div>
      </div>

      <div className="panel">
        <div className="panel-header">
          <h2>Verification history</h2>
        </div>
        <div className="panel-body" style={{ padding: 0 }}>
          {loading && <p className="helper-text" style={{ padding: 18 }}>Loading history…</p>}
          {error && <div className="error-banner" style={{ margin: 18 }}>{error}</div>}
          {!loading && !error && history.length === 0 && (
            <p className="helper-text" style={{ padding: 18 }}>
              No verification runs yet. Results from single, batch, and coordinate lookups will
              appear here once your backend returns them from{' '}
              <code style={{ fontFamily: 'var(--font-mono)' }}>/api/results</code>.
            </p>
          )}
          {history.length > 0 && (
            <table className="batch-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Lat, Lon</th>
                  <th>Solar</th>
                  <th>Confidence</th>
                  <th>Area (m²)</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {history.map((r, i) => (
                  <tr key={r.sample_id ?? i}>
                    <td>{r.sample_id ?? i}</td>
                    <td>
                      {r.lat?.toFixed?.(4)}, {r.lon?.toFixed?.(4)}
                    </td>
                    <td>{r.has_solar ? 'Yes' : 'No'}</td>
                    <td>{r.confidence !== undefined ? `${(r.confidence * 100).toFixed(1)}%` : '—'}</td>
                    <td>{r.pv_area_sqm_est?.toFixed?.(1) ?? '—'}</td>
                    <td>
                      <StatusBadge status={r.qc_status} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  )
}
