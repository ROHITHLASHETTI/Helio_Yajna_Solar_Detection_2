import { useState, useRef } from 'react'
import { detectSingle } from '../api.js'
import ResultCard from './ResultCard.jsx'

export default function SingleUpload() {
  const [file, setFile] = useState(null)
  const [previewUrl, setPreviewUrl] = useState(null)
  const [bufferRadius, setBufferRadius] = useState(2400)
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [drag, setDrag] = useState(false)
  const inputRef = useRef(null)

  function handleFile(f) {
    if (!f) return
    setFile(f)
    setPreviewUrl(URL.createObjectURL(f))
    setResult(null)
    setError(null)
  }

  async function runDetection() {
    if (!file) return
    setLoading(true)
    setError(null)
    try {
      const data = await detectSingle(file, { bufferRadiusSqft: bufferRadius })
      setResult(data)
    } catch (err) {
      setError(err.message || 'Detection failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="two-col">
      <div className="panel">
        <div className="panel-header">
          <h2>Rooftop image</h2>
        </div>
        <div className="panel-body">
          <div
            className={`dropzone ${drag ? 'drag' : ''}`}
            onClick={() => inputRef.current?.click()}
            onDragOver={(e) => {
              e.preventDefault()
              setDrag(true)
            }}
            onDragLeave={() => setDrag(false)}
            onDrop={(e) => {
              e.preventDefault()
              setDrag(false)
              handleFile(e.dataTransfer.files?.[0])
            }}
          >
            {previewUrl ? (
              <img src={previewUrl} alt="preview" className="preview-thumb" />
            ) : (
              <>
                <div className="icon">▲</div>
                <p>Drop a satellite image, or click to browse</p>
                <div className="hint">JPG · PNG · TIFF, 1280×1280 recommended</div>
              </>
            )}
          </div>
          <input
            ref={inputRef}
            type="file"
            accept="image/*"
            hidden
            onChange={(e) => handleFile(e.target.files?.[0])}
          />

          <div className="field" style={{ marginTop: 16 }}>
            <label>Buffer radius (sqft)</label>
            <input
              type="number"
              value={bufferRadius}
              onChange={(e) => setBufferRadius(Number(e.target.value))}
            />
          </div>

          {error && <div className="error-banner">{error}</div>}

          <button className="btn btn-primary" onClick={runDetection} disabled={!file || loading}>
            {loading && <span className="spinner" />}
            {loading ? 'Running detection…' : 'Run detection'}
          </button>
        </div>
      </div>

      <div className="panel">
        <div className="panel-header">
          <h2>Verification output</h2>
        </div>
        <div className="panel-body">
          <ResultCard result={result} previewUrl={result ? previewUrl : null} />
        </div>
      </div>
    </div>
  )
}
