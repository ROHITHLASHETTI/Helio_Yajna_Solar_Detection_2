import { useState } from 'react'
import { detectByCoordinates } from '../api.js'
import ResultCard from './ResultCard.jsx'
import MapPicker from './MapPicker.jsx'

export default function CoordinateSearch() {
  const [lat, setLat] = useState('')
  const [lon, setLon] = useState('')
  const [bufferRadius, setBufferRadius] = useState(2400)
  const [result, setResult] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)

  const valid = lat !== '' && lon !== '' && !Number.isNaN(Number(lat)) && !Number.isNaN(Number(lon))

  async function runDetection(latOverride, lonOverride) {
    const useLat = latOverride ?? Number(lat)
    const useLon = lonOverride ?? Number(lon)
    if (Number.isNaN(useLat) || Number.isNaN(useLon)) return

    setLoading(true)
    setError(null)
    try {
      const data = await detectByCoordinates({
        lat: useLat,
        lon: useLon,
        bufferRadiusSqft: bufferRadius,
      })
      setResult(data)
    } catch (err) {
      setError(err.message || 'Lookup failed')
    } finally {
      setLoading(false)
    }
  }

  function handleMapPick(pickedLat, pickedLon) {
    setLat(pickedLat.toFixed(5))
    setLon(pickedLon.toFixed(5))
    setResult(null)
    runDetection(pickedLat, pickedLon)
  }

  return (
    <div className="two-col">
      <div className="panel">
        <div className="panel-header">
          <h2>Click a rooftop to verify</h2>
          <span className="helper-text">{loading ? 'Detecting…' : 'Click the map'}</span>
        </div>
        <div className="panel-body" style={{ padding: 0 }}>
          <MapPicker lat={lat} lon={lon} onPick={handleMapPick} disabled={loading} />
        </div>
        <div className="panel-body">
          <p className="helper-text" style={{ marginBottom: 16 }}>
            Clicking the map fetches the satellite tile at that coordinate and runs detection
            immediately. Adjust the values below for a precise location, then re-run manually.
          </p>

          <div className="field-row">
            <div className="field">
              <label>Latitude</label>
              <input
                type="text"
                placeholder="25.1333"
                value={lat}
                onChange={(e) => setLat(e.target.value)}
              />
            </div>
            <div className="field">
              <label>Longitude</label>
              <input
                type="text"
                placeholder="71.1833"
                value={lon}
                onChange={(e) => setLon(e.target.value)}
              />
            </div>
          </div>
          <div className="field">
            <label>Buffer radius (sqft)</label>
            <input
              type="number"
              value={bufferRadius}
              onChange={(e) => setBufferRadius(Number(e.target.value))}
            />
          </div>

          {error && <div className="error-banner">{error}</div>}

          <button
            className="btn btn-primary"
            onClick={() => runDetection()}
            disabled={!valid || loading}
          >
            {loading && <span className="spinner" />}
            {loading ? 'Fetching site…' : 'Fetch & verify site'}
          </button>
        </div>
      </div>

      <div className="panel">
        <div className="panel-header">
          <h2>Verification output</h2>
        </div>
        <div className="panel-body">
          <ResultCard result={result} />
        </div>
      </div>
    </div>
  )
}
