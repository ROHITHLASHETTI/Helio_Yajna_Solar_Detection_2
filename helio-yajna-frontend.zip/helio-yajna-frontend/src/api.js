// -----------------------------------------------------------------------
// Helio Yajna API layer
//
// Expected response shape for every detection call (single object, or an
// array of these for batch):
//
// {
//   sample_id: string,
//   lat: number,
//   lon: number,
//   has_solar: boolean,
//   confidence: number,               // 0..1
//   pv_area_sqm_est: number,
//   euclidean_distance_m_est: number,
//   buffer_radius_sqft: number,
//   qc_status: "VERIFIABLE" | "FLAGGED" | "PENDING" | "NOT_FOUND",
//   bbox_or_mask: number[][] | [],    // polygon points [[x,y], ...] in
//                                      // image pixel space, or [] if none
//   image_metadata: {
//     source: string,                 // e.g. "Cache" | "Live" | "Upload"
//     capture_date: string,           // ISO date
//     zoom: number,
//     inference_mode: string,         // e.g. "detected" | "not_found"
//   }
// }
//
// Adjust ENDPOINTS below to match your backend's actual routes — nothing
// else in the app needs to change.
// -----------------------------------------------------------------------

const BASE_URL = import.meta.env.VITE_API_BASE_URL || ''

const ENDPOINTS = {
  detectImage: '/api/detect/image',
  detectBatch: '/api/detect/batch',
  detectCoordinates: '/api/detect/coordinates',
  history: '/api/results',
}

class ApiError extends Error {
  constructor(message, status) {
    super(message)
    this.status = status
  }
}

async function request(path, options = {}) {
  const res = await fetch(`${BASE_URL}${path}`, options)
  if (!res.ok) {
    const body = await res.text().catch(() => '')
    throw new ApiError(body || res.statusText, res.status)
  }
  return res.json()
}

export async function detectSingle(file, { bufferRadiusSqft } = {}) {
  const form = new FormData()
  form.append('image', file)
  if (bufferRadiusSqft) form.append('buffer_radius_sqft', String(bufferRadiusSqft))
  return request(ENDPOINTS.detectImage, { method: 'POST', body: form })
}

export async function detectBatch(files, { bufferRadiusSqft } = {}) {
  const form = new FormData()
  files.forEach((file) => form.append('images', file))
  if (bufferRadiusSqft) form.append('buffer_radius_sqft', String(bufferRadiusSqft))
  return request(ENDPOINTS.detectBatch, { method: 'POST', body: form })
}

export async function detectByCoordinates({ lat, lon, bufferRadiusSqft }) {
  return request(ENDPOINTS.detectCoordinates, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ lat, lon, buffer_radius_sqft: bufferRadiusSqft }),
  })
}

export async function fetchHistory() {
  return request(ENDPOINTS.history, { method: 'GET' })
}

export { ApiError }
