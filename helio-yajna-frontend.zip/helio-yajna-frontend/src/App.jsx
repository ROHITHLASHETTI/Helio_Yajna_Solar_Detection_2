import { useState } from 'react'
import Dashboard from './components/Dashboard.jsx'
import SingleUpload from './components/SingleUpload.jsx'
import BatchUpload from './components/BatchUpload.jsx'
import CoordinateSearch from './components/CoordinateSearch.jsx'

const MODES = [
  { key: 'dashboard', label: 'Dashboard', icon: '▦' },
  { key: 'single', label: 'Single image', icon: '▲' },
  { key: 'batch', label: 'Batch', icon: '▤' },
  { key: 'coordinates', label: 'Coordinates', icon: '⊕' },
]

const TITLES = {
  dashboard: ['Verification dashboard', 'Fleet-wide audit summary'],
  single: ['Single-site detection', 'Upload one rooftop image for instance segmentation'],
  batch: ['Batch verification', 'Upload a set of rooftop images for bulk processing'],
  coordinates: ['Coordinate lookup', 'Fetch satellite imagery by lat/lon and verify'],
}

export default function App() {
  const [mode, setMode] = useState('dashboard')
  const [title, sub] = TITLES[mode]

  return (
    <div className="shell">
      <nav className="rail">
        <div className="rail-mark">HY</div>
        {MODES.map((m) => (
          <button
            key={m.key}
            className={`rail-btn ${mode === m.key ? 'active' : ''}`}
            onClick={() => setMode(m.key)}
            title={m.label}
          >
            {m.icon}
          </button>
        ))}
      </nav>

      <div className="main">
        <header className="topbar">
          <div>
            <h1>{title}</h1>
            <div className="sub">{sub}</div>
          </div>
          <div className="mode-tabs">
            {MODES.map((m) => (
              <button
                key={m.key}
                className={`mode-tab ${mode === m.key ? 'active' : ''}`}
                onClick={() => setMode(m.key)}
              >
                {m.label}
              </button>
            ))}
          </div>
        </header>

        <div className="content">
          {mode === 'dashboard' && <Dashboard />}
          {mode === 'single' && <SingleUpload />}
          {mode === 'batch' && <BatchUpload />}
          {mode === 'coordinates' && <CoordinateSearch />}
        </div>
      </div>
    </div>
  )
}
